var searchData=
[
  ['callbackdata_0',['CallbackData',['../d2/dc3/struct_callback_data.html',1,'']]],
  ['compactcontext_1',['CompactContext',['../d2/ddd/struct_compact_context.html',1,'']]]
];
