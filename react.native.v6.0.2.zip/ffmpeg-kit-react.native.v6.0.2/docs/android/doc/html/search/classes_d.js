var searchData=
[
  ['readinterval_0',['ReadInterval',['../d8/dee/struct_read_interval.html',1,'']]]
];
