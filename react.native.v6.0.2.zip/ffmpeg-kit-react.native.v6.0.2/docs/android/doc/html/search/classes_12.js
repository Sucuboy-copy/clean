var searchData=
[
  ['xmlcontext_0',['XMLContext',['../d7/db2/struct_x_m_l_context.html',1,'']]]
];
